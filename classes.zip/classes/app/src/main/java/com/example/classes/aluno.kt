package com.example.classes

data class aluno(var nome: String, var endereco: String, var cpf : String, var sexo: String ) {

}